import java.util.*;

/**
 * Simple 8-puzzle solver using BFS, DFS, and A* search.
 *
 * State representation: String of length 9, e.g. "724506831"
 * '0' represents the blank tile.
 *
 * Goal: "123456780"
 */
public class Puzzle8Solver {

    private static final String GOAL = "123456780";

    // Directions for readability
    private static final String[] MOVES = {"Up", "Down", "Left", "Right"};
    private static final int[] DR = {-1, 1, 0, 0};
    private static final int[] DC = {0, 0, -1, 1};

    static class Node {
        String state;
        Node parent;
        String move; // move taken from parent to this node
        int g;       // cost so far (depth)
        int h;       // heuristic (for A*)

        Node(String state, Node parent, String move, int g, int h) {
            this.state = state;
            this.parent = parent;
            this.move = move;
            this.g = g;
            this.h = h;
        }

        int f() {
            return g + h;
        }
    }

    public static void main(String[] args) {
        // Example start state (known solvable)
        // 7 2 4
        // 5 0 6
        // 8 3 1
        String start = "724506831";

        // Optional: override from command line: java Puzzle8Solver 724506831 123456780
        if (args.length >= 1) {
            start = args[0];
        }

        System.out.println("Start state: " + start);
        System.out.println("Goal state : " + GOAL);

        if (!isSolvable(start, GOAL)) {
            System.out.println("This puzzle is NOT solvable.");
            return;
        }

        System.out.println("\n===== BFS =====");
        runAndPrint(start, GOAL, "BFS");

        System.out.println("\n===== DFS (depth limit 25) =====");
        runAndPrint(start, GOAL, "DFS");

        System.out.println("\n===== A* (Manhattan) =====");
        runAndPrint(start, GOAL, "ASTAR");
    }

    private static void runAndPrint(String start, String goal, String method) {
        long t0 = System.currentTimeMillis();
        SearchResult result;

        switch (method) {
            case "BFS":
                result = bfs(start, goal);
                break;
            case "DFS":
                result = dfs(start, goal, 25); // depth limit
                break;
            case "ASTAR":
                result = aStar(start, goal);
                break;
            default:
                throw new IllegalArgumentException("Unknown method: " + method);
        }

        long t1 = System.currentTimeMillis();
        if (result.path == null) {
            System.out.println("No solution found (within limits).");
        } else {
            System.out.println("Solution depth: " + (result.path.size() - 1));
            System.out.println("Nodes expanded: " + result.nodesExpanded);
            System.out.println("Time: " + (t1 - t0) + " ms");
            System.out.println("\nSolution path:");
            printPath(result.path);
        }
    }

    // ================== SOLVABILITY CHECK ==================

    /**
     * For 3x3 puzzle:
     * A configuration is solvable iff initial and goal have same inversion parity.
     */
    public static boolean isSolvable(String start, String goal) {
        int invStart = inversionCount(start);
        int invGoal = inversionCount(goal);
        return (invStart % 2) == (invGoal % 2);
    }

    private static int inversionCount(String state) {
        int inv = 0;
        List<Integer> nums = new ArrayList<>();
        for (char c : state.toCharArray()) {
            if (c != '0') {
                nums.add(c - '0');
            }
        }
        for (int i = 0; i < nums.size(); i++) {
            for (int j = i + 1; j < nums.size(); j++) {
                if (nums.get(i) > nums.get(j)) {
                    inv++;
                }
            }
        }
        return inv;
    }

    // ================== BFS ==================

    static class SearchResult {
        List<Node> path;
        int nodesExpanded;

        SearchResult(List<Node> path, int nodesExpanded) {
            this.path = path;
            this.nodesExpanded = nodesExpanded;
        }
    }

    public static SearchResult bfs(String start, String goal) {
        Queue<Node> queue = new LinkedList<>();
        Set<String> visited = new HashSet<>();

        Node root = new Node(start, null, null, 0, 0);
        queue.add(root);
        visited.add(start);

        int expanded = 0;

        while (!queue.isEmpty()) {
            Node current = queue.poll();
            expanded++;

            if (current.state.equals(goal)) {
                return new SearchResult(buildPath(current), expanded);
            }

            for (Node neighbor : expand(current, goal, false)) { // h not needed for BFS
                if (!visited.contains(neighbor.state)) {
                    visited.add(neighbor.state);
                    queue.add(neighbor);
                }
            }
        }
        return new SearchResult(null, expanded);
    }

    // ================== DFS (Depth-limited) ==================

    public static SearchResult dfs(String start, String goal, int depthLimit) {
        Deque<Node> stack = new ArrayDeque<>();
        // track best depth we’ve seen a state at (to reduce pointless revisits)
        Map<String, Integer> visitedDepth = new HashMap<>();

        Node root = new Node(start, null, null, 0, 0);
        stack.push(root);
        visitedDepth.put(start, 0);

        int expanded = 0;

        while (!stack.isEmpty()) {
            Node current = stack.pop();
            expanded++;

            if (current.state.equals(goal)) {
                return new SearchResult(buildPath(current), expanded);
            }

            if (current.g >= depthLimit) {
                continue;
            }

            // expand children, push them on stack (LIFO)
            List<Node> neighbors = expand(current, goal, false);
            // optional: reverse to change DFS ordering of moves
            Collections.reverse(neighbors);
            for (Node neighbor : neighbors) {
                Integer bestDepth = visitedDepth.get(neighbor.state);
                if (bestDepth == null || neighbor.g < bestDepth) {
                    visitedDepth.put(neighbor.state, neighbor.g);
                    stack.push(neighbor);
                }
            }
        }

        return new SearchResult(null, expanded);
    }

    // ================== A* (Manhattan) ==================

    public static SearchResult aStar(String start, String goal) {
        PriorityQueue<Node> open = new PriorityQueue<>(Comparator.comparingInt(Node::f));
        Map<String, Integer> bestG = new HashMap<>();
        Set<String> closed = new HashSet<>();

        Node root = new Node(start, null, null, 0, manhattan(start, goal));
        open.add(root);
        bestG.put(start, 0);

        int expanded = 0;

        while (!open.isEmpty()) {
            Node current = open.poll();

            if (closed.contains(current.state)) {
                continue;
            }

            closed.add(current.state);
            expanded++;

            if (current.state.equals(goal)) {
                return new SearchResult(buildPath(current), expanded);
            }

            for (Node neighbor : expand(current, goal, true)) {
                if (closed.contains(neighbor.state)) {
                    continue;
                }
                Integer best = bestG.get(neighbor.state);
                if (best == null || neighbor.g < best) {
                    bestG.put(neighbor.state, neighbor.g);
                    open.add(neighbor);
                }
            }
        }

        return new SearchResult(null, expanded);
    }

    // ================== COMMON UTILITIES ==================

    private static List<Node> expand(Node node, String goal, boolean useHeuristic) {
        List<Node> result = new ArrayList<>();
        String state = node.state;
        int zeroIndex = state.indexOf('0');
        int zr = zeroIndex / 3;
        int zc = zeroIndex % 3;

        for (int i = 0; i < 4; i++) {
            int nr = zr + DR[i];
            int nc = zc + DC[i];
            if (nr < 0 || nr >= 3 || nc < 0 || nc >= 3) continue;

            int newIndex = nr * 3 + nc;
            String newState = swap(state, zeroIndex, newIndex);

            int g = node.g + 1;
            int h = useHeuristic ? manhattan(newState, goal) : 0;
            Node child = new Node(newState, node, MOVES[i], g, h);
            result.add(child);
        }
        return result;
    }

    private static String swap(String s, int i, int j) {
        char[] arr = s.toCharArray();
        char tmp = arr[i];
        arr[i] = arr[j];
        arr[j] = tmp;
        return new String(arr);
    }

    private static int manhattan(String state, String goal) {
        int dist = 0;
        for (int i = 0; i < 9; i++) {
            char c = state.charAt(i);
            if (c == '0') continue;
            int val = c - '0';

            int goalIndex = goal.indexOf(c);
            int r1 = i / 3, c1 = i % 3;
            int r2 = goalIndex / 3, c2 = goalIndex % 3;
            dist += Math.abs(r1 - r2) + Math.abs(c1 - c2);
        }
        return dist;
    }

    private static List<Node> buildPath(Node goalNode) {
        List<Node> path = new ArrayList<>();
        Node current = goalNode;
        while (current != null) {
            path.add(current);
            current = current.parent;
        }
        Collections.reverse(path);
        return path;
    }

    private static void printPath(List<Node> path) {
        for (int i = 0; i < path.size(); i++) {
            Node n = path.get(i);
            if (n.move != null) {
                System.out.println("Step " + i + " (move: " + n.move + ")");
            } else {
                System.out.println("Step " + i + " (start)");
            }
            printState(n.state);
            System.out.println();
        }
    }

    private static void printState(String state) {
        for (int i = 0; i < 9; i++) {
            char c = state.charAt(i);
            System.out.print((c == '0' ? " " : c) + " ");
            if (i % 3 == 2) System.out.println();
        }
    }
}
